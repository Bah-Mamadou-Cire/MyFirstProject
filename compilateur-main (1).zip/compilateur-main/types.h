typedef enum {
    INT_T,
    BOOL_T,
    ERR_T
} vartype;