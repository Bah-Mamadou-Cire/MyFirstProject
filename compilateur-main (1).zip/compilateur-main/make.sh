make > make.log 2>&1 3>&1
./source > f.asm < test.tex
asipro f.asm expr 2> asipro.log
sipro expr
