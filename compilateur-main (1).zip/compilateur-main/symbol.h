#ifndef SYMBOL_H
#define SYMBOL_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TABLE_SIZE 100

typedef enum { NUMBER, BOOLEAN, NONE } type1;
typedef enum { FCT, PARAM, VLOC, BLOC } type2;

struct data {
    char *id;
    type1 type;
    type2 type_var;
    char * fc_name ;
    int ordre;
    int nbpar;
    int nbvar;
    struct data *next;
};

struct hash_table {
    struct data *table[TABLE_SIZE];
};

struct hash_table *createTable();

unsigned int hash_function(char *id);

void incPar(struct hash_table *table, char *id);

void incVar(struct hash_table *table, char *id);

struct data *searchSymbole3(struct hash_table *table, char *s, int ordre);

struct data *nouveauSymbole(char *id, type1 type, type2 type_var, int ordre, int nb1, int nb2, char * fname);

int ajouterSymbole(struct hash_table *table, char *id, type1 type, type2 type_var, char * fname);

int ajouterSymbole1(struct hash_table *table, char *id, type1 type, type2 type_var, int nbpar, int nbvar);

struct data *searchSymbole(struct hash_table *table, char *id);

struct data *searchSymbole1(struct hash_table *table, char *id, char * s);

int searchSymboleOrder(struct hash_table *table, char *id);

int searchSymboleOrderFCT(struct hash_table *table, char *id, char * s);

void freeTable(struct hash_table *table);

void incrementer_nbpar(struct hash_table *table, char *id);

const char *typeToString(type1 t);

const char *typeVarToString(type2 t);

void afficherTableSymboles(struct hash_table *table);

#endif
