#ifndef LIST_H
#define LIST_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include "symbol.h"

#define MAX_SIZE 100
#define INITIAL_CAPACITY 100
#define BUF_SIZE 2048

typedef struct Node {
    char *data;
    char *param;
    struct Node *next;
} Node;


Node* createNode(char *data, char *args);

void freeList();

void append(Node **head, char *data, char *arg);

char* substr(char *s, int n);

int toInt(char *s);

int get(char *element);

void processAndDisplayAsm(struct hash_table *table);

void addData(const char *format, va_list args, char *data);

void cprint(const char *format, ...);

#endif
