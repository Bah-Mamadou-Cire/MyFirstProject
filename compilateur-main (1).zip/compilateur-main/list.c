#include "list.h"   
#include "symbol.h" 

// Déclarations des variables globales
char lastAlgo[BUF_SIZE];    // Dernier algorithme
int lastAlgoSize;           // Taille du dernier algorithme
char *lastAlgo1[BUF_SIZE];  // Dernier algorithme 1
int numerotation1;          // Numérotation 1

char *blocName[100];    // Nom de bloc
int bloc[BUF_SIZE];     // Bloc
int nombre_elements;    // Nombre d'éléments
int position;            // Position
int position1;           // Position 1

Node * head = NULL;     // Tête de la liste chaînée

// Crée un nouveau nœud pour la liste chaînée
Node* createNode(char *data, char * args) {
    Node *newNode = (Node *)malloc(sizeof(Node)); // Alloue de la mémoire pour le nouveau nœud
    if (newNode != NULL) {
        newNode->data = strdup(data);   // Copie la chaîne de données dans le nouveau nœud
        newNode->param = strdup(args);  // Copie les arguments dans le nouveau nœud
        newNode->next = NULL;           // Initialise le prochain nœud à NULL
    }
    return newNode; // Retourne le nouveau nœud
}

// Libère la mémoire utilisée par tous les éléments de la liste chaînée
void freeList() {
    Node *current = head; // Nœud courant
    while (current != NULL) {
        Node *temp = current;     // Stocke le nœud courant temporairement
        current = current->next;  // Passe au prochain nœud
        free(temp->data);         // Libère la mémoire de la chaîne de données
        free(temp);               // Libère la mémoire du nœud
    }
}

// Ajoute un nouvel élément à la fin de la liste chaînée
void append(Node **head, char *data, char *arg) {
    Node *newNode = createNode(data,arg); // Crée un nouveau nœud avec les données spécifiées
    if (newNode == NULL) {  // Vérifie si la création du nœud a échoué
        fprintf(stderr, "Erreur : Impossible de créer un nouvel élément.\n");
        return;
    }
    if (*head == NULL) {   // Si la liste est vide, le nouvel élément devient la tête
        *head = newNode;
        return;
    }
    Node *current = *head; // Nœud courant
    while (current->next != NULL) { // Parcourt la liste jusqu'au dernier élément
        current = current->next;
    }
    current->next = newNode; // Ajoute le nouvel élément à la fin de la liste
}

// Fonction utilitaire pour récupérer la sous-chaîne à partir de l'indice spécifié
char* substr(char *s, int n) {
    if (n >= strlen(s)) {
        // Si n est supérieur ou égal à la longueur de la chaîne,
        // retourner une chaîne vide ou une indication d'erreur selon le cas.
        return ""; // ou return NULL; selon la convention que vous voulez suivre
    } else {
        // Sinon, retourner une sous-chaîne à partir de l'indice n
        return s + n;
    }
}

// Convertit une chaîne en entier, renvoie -1 en cas d'erreur
int toInt(char * s) {
    char * p ;
    int intvar = strtol(s, &p, 10); // Convertit la chaîne en entier
    if(s==p){ // Vérifie si la conversion a échoué
        return -1; // Retourne -1 en cas d'échec
    } 
    return intvar; // Retourne l'entier converti
}

// Recherche un élément dans le tableau blocName et retourne sa position
int get(char *element) {
    // Parcourt le tableau blocName à partir de la fin
    for (int i = position1 - 1; i >= 0; i--) {
        // Vérifie si l'élément actuel correspond à l'élément recherché
        if (strcmp(blocName[i], element) == 0) {
            return i; // Retourne la position de l'élément s'il est trouvé
        }
    }
    return -1; // Retourne -1 si l'élément n'est pas trouvé
}

/**
Affiche tous les éléments de la liste chaînée avec des manipulations spécifiques
Fonction Coeur du système qui génère le code intermédiaire
*/
void processAndDisplayAsm(struct hash_table *table) {
    Node *current = head;
    while (current != NULL) {
        if (strcmp(current->param, "") == 0) {
            char data[BUF_SIZE];
            strcpy(data, current->data); 
            data[strlen(current->data)-1] = '\0'; 

            if(strncmp(current->data, ":", 1)==0){
                    char * a = substr(data,1);
                    int r = get(a);
                    if(strcmp(a, "debutprog")==0){
                        printf(current->data);
                    }
                    else{
                        if(r == -1 || bloc[r] == 2){
                            bloc[position] = 1;
                            blocName[position1] = (char *)malloc(strlen(a) + 1);
                            strcpy(blocName[position1], a);
                            r=position;
                            position1++;
                            position++;
                        }else{
                            if(bloc[r]==1){
                                bloc[r] = 2;
                            }
                        }
                        printf(":%s%d\n", a, r);
                    }                               
            }
            else if(strncmp(current->data, "\tconst", 6) == 0){
                char * a = substr(data,10);
                
                if(toInt(a)==-1){
                    if(strcmp(a, "nl")==0){
                        printf(current->data);
                    }
                    else if(strcmp(a, "finprog")==0){
                        printf(current->data);
                    }
                    else if(strcmp(a, "errDiv0")==0){
                        printf(current->data);
                    }
                    
                    else{
                        int r = get(a);
                        int k = position-1;
                    
                        if(r == -1 || bloc[r] == 2){
                        
                            bloc[position] = 1;
                            blocName[position1] = (char *)malloc(strlen(a) + 1);
                            strcpy(blocName[position1], a);
                            r=position;
                            k = position-1;
                            position1++;
                            position++;
                        }
                        else{
                            if(bloc[r]==1){
                                bloc[r] = 2;
                            }
                        }
                        
                        if(!(k>=0 && (bloc[r]==1 && strcmp(blocName[k],a)==0)))
                        {
                            printf("%s%d\n", data, r);
                        }
                    }
                }else{
                    printf(current->data);
                }
            }
            else{
                printf(current->data);
            }
        } else {
            struct data * search =  searchSymbole(table, current->param);
            if(search != NULL){
                int r = searchSymboleOrder(table, current->param);
                if(search->type_var == FCT){
                    
                    if(strncmp(current->data, "\tconst", 6) == 0){
                        char buff[BUF_SIZE];
                        if(
                            (strncmp(current->data, "\tconst ax,%", 11)==0) ||
                            (strncmp(current->data, "\tconst bx,%", 11)==0) ||
                            (strncmp(current->data, "\tconst cx,%", 11)==0) ||
                            (strncmp(current->data, "\tconst dx,%", 11)==0)
                        ){
                            snprintf(lastAlgo, BUF_SIZE, "%s", search->fc_name);
                            snprintf(buff, BUF_SIZE, current->data, "");
                            int offset = strlen(buff);
                            char number_str[20];
                            snprintf(number_str, sizeof(number_str), "%d", r);
                            snprintf(buff + offset, BUF_SIZE - offset, "%s", number_str);
                            printf("%s\n", buff);
                        }else{
                            sprintf(buff, current->data, current->param);
                            int offset = strlen(buff);
                            char number_str[20]; 
                            snprintf(number_str, sizeof(number_str), "%d", r);
                            snprintf(buff + offset, BUF_SIZE - offset, "%s", number_str);
                            printf("%s\n", buff);
                        }
                    }
                    else{
                        snprintf(lastAlgo, BUF_SIZE, "%s", search->fc_name);
                        char buff[BUF_SIZE];
                        snprintf(buff, BUF_SIZE, current->data, current->param);
                        int offset = strlen(buff);
                        char number_str[20]; 
                        snprintf(number_str, sizeof(number_str), "%d", r);
                        snprintf(buff + offset, BUF_SIZE - offset, "%s", number_str);
                        printf("%s\n", buff);
                    }
                }else{
                    int r = searchSymboleOrderFCT(table, current->param, lastAlgo);
                    
                    char buff[BUF_SIZE];
                    sprintf(buff, current->data, "");
                    int offset = strlen(buff);
                    char number_str[20]; 
                    snprintf(number_str, sizeof(number_str), "%d", r);
                    snprintf(buff + offset, BUF_SIZE - offset, "%s", number_str);
                    printf("%s\n", buff);
                }
            }
        }
        current = current->next;
    }
}

// Fonction utilitaire pour afficher et ajouter les données à la liste chaînée
void addData(const char *format, va_list args, char * data) {
    const char *ptr = format; // Pointeur pour parcourir le format
    char * arg = NULL; // Argument temporaire initialisé à NULL
    while (*ptr != '\0') {
        if (*ptr == '%' && *(ptr + 1) == 's') {
            arg = va_arg(args, char*); // Récupère l'argument de la liste variable
            ptr += 2; // Passe au prochain caractère après l'argument
        } 
        else {
            ptr++; // Passe au prochain caractère
        }
    }
    // Ajoute l'élément avec les arguments à la liste chaînée
    if(arg != NULL) {
        append(&head, (char *) format, arg);
    } else {
        append(&head, (char *) data, "");
    }
}

// Fonction printf personnalisée qui prépare les données à ajouter à la liste chaînée
void cprint(const char *format, ...) {
    va_list args; // Liste variable d'arguments
    va_start(args, format); // Initialise la liste variable avec le format

    // Utiliser vsnprintf avec NULL pour obtenir la longueur nécessaire du buffer
    int length = vsnprintf(NULL, 0, format, args);
    va_end(args); // Termine l'utilisation de la liste variable

    // Alloue dynamiquement un nouveau buffer avec la longueur calculée
    char* buffer = (char*)malloc((length + 1) * sizeof(char)); // +1 pour le caractère de terminaison de chaîne
    if (buffer == NULL) {
        fprintf(stderr, "Erreur : impossible d'allouer de la mémoire pour le buffer.\n");
        exit(EXIT_FAILURE);
    }

    // Formatter la chaîne dans le nouveau buffer
    va_start(args, format); // Réinitialiser l'argument variable
    vsnprintf(buffer, length + 1, format, args); // +1 pour le caractère de terminaison de chaîne
    va_end(args); // Termine l'utilisation de la liste variable

    // Afficher tous les arguments
    va_start(args, format); // Réinitialiser l'argument variable
    addData(format, args, buffer); // Affiche et ajoute les arguments à la liste chaînée
    va_end(args); // Termine l'utilisation de la liste variable

    // Libérer le buffer original, maintenant que sa copie a été ajoutée à la liste
    free(buffer);

   
}
