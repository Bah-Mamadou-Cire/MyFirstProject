#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "symbol.h"

// Variables globales pour suivre le dernier ordre utilisé et le nombre de fonctions
int dernier_ordre_utilise = -1;
int fct_count = 0;

// Crée une nouvelle table de hachage
struct hash_table *createTable() {
    struct hash_table *table = (struct hash_table *)malloc(sizeof(struct hash_table));
    if (table == NULL) {
        fprintf(stderr, "Erreur lors de l'allocation de mémoire pour la table de hachage.\n");
        exit(EXIT_FAILURE);
    }
    // Initialise chaque entrée de la table à NULL
    for (int i = 0; i < TABLE_SIZE; i++) {
        table->table[i] = NULL;
    }
    return table;
}

// Fonction de hachage simple pour les chaînes de caractères
unsigned int hash_function(char *id) {
    unsigned int hash = 0;
    for (int i = 0; id[i] != '\0'; i++) {
        hash = (hash * 31) + id[i];
    }
    return hash % TABLE_SIZE;
}

// Implémente strdup qui n'est pas standard dans C
char *strdup(const char *s) {
    char *d = malloc(strlen(s) + 1);
    if (d == NULL) return NULL;
    strcpy(d, s);
    return d;
}

// Incrémente le nombre de paramètres pour une fonction donnée
void incPar(struct hash_table *table, char *id) {
    unsigned int index = hash_function(id);
    struct data *courant = table->table[index];
    while (courant != NULL) {
        if (strcmp(id, courant->id) == 0) {
            courant->nbpar++;
            return;
        }
        courant = courant->next;
    }
}

// Incrémente le nombre de variables locales pour une fonction donnée
void incVar(struct hash_table *table, char *id) {
    unsigned int index = hash_function(id);
    struct data *courant = table->table[index];
    while (courant != NULL) {
        if (strcmp(id, courant->id) == 0) {
            courant->nbvar++;
            return;
        }
        courant = courant->next;
    }
}

// Crée un nouveau symbole avec les informations fournies
struct data *nouveauSymbole(char *id, type1 type, type2 type_var, int ordre, int nb1, int nb2, char *fname) {
    struct data *nouveau = (struct data *)malloc(sizeof(struct data));
    if (nouveau == NULL) {
        fprintf(stderr, "Erreur lors de l'allocation de mémoire.\n");
        exit(EXIT_FAILURE);
    }
    // Initialise les champs du symbole avec les valeurs fournies
    nouveau->id = strdup(id);
    nouveau->type = type;
    nouveau->type_var = type_var;
    nouveau->ordre = ordre;
    nouveau->nbpar = nb1;
    nouveau->nbvar = nb2;
    nouveau->fc_name = fname;
    nouveau->next = NULL;
    return nouveau;
}

// Ajoute un symbole à la table de hachage
int ajouterSymbole(struct hash_table *table, char *id, type1 type, type2 type_var, char *fname) {
    unsigned int index = hash_function(id);
    int ordre = dernier_ordre_utilise; // Utilise le dernier ordre utilisé
    
    // Si le symbole est une fonction, réinitialise l'ordre et incrémente le compteur de fonctions
    if(strcmp(id, fname) == 0){
        dernier_ordre_utilise=-1;
        ordre = -1;
        fct_count++;
    }
    
    // Crée un nouveau symbole et l'ajoute à la table de hachage
    struct data *nouveau = nouveauSymbole(id, type, type_var, ordre, 0, 0, fname);
    if(type_var == PARAM){
        incPar(table, fname);
    }else if(type_var == VLOC){
        incVar(table, fname);
    }
    nouveau->next = table->table[index];
    table->table[index] = nouveau;
    dernier_ordre_utilise += 1; // Incrémente le dernier ordre utilisé pour le prochain ajout
    return nouveau->ordre;
}

// Ajoute un symbole avec des informations supplémentaires à la table de hachage
int ajouterSymbole1(struct hash_table *table, char *id, type1 type, type2 type_var, int nbpar, int nbvar) {
    unsigned int index = hash_function(id);
    int ordre = dernier_ordre_utilise; // Utilise le dernier ordre utilisé
    struct data *nouveau = nouveauSymbole(id, type, type_var, ordre, nbpar, nbvar, id);
    nouveau->next = table->table[index];
    table->table[index] = nouveau;
    dernier_ordre_utilise += 1; // Incrémente le dernier ordre utilisé pour le prochain ajout
    return nouveau->ordre;
}

// Recherche un symbole par son identifiant dans la table de hachage
struct data *searchSymbole(struct hash_table *table, char *id) {
    unsigned int index = hash_function(id);
    struct data *courant = table->table[index];
    while (courant != NULL) {
        if (strcmp(id, courant->id) == 0) {
            return courant;
        }
        courant = courant->next;
    }
    return NULL;
}

// Recherche un symbole par son nom de fonction et son ordre dans la table de hachage
struct data *searchSymbole3(struct hash_table *table, char *s, int ordre) {
    // Parcourt la table de hachage
    for (int i = 0; i < TABLE_SIZE; i++) {
        struct data *courant = table->table[i];
        // Parcourt la liste chaînée à l'index actuel
        while (courant != NULL) {
            // Vérifie si le champ fc_name correspond à la chaîne s et si l'ordre correspond
            if ((strcmp(s, courant->fc_name) == 0) && courant->ordre == ordre) {
                // Si la correspondance est trouvée, retourne l'élément actuel
                return courant;
            }
            courant = courant->next;
        }
    }
    // Si aucun élément ne correspond, retourne NULL
    return NULL;
}

// Recherche un symbole par son identifiant et le nom de sa fonction dans la table de hachage
struct data *searchSymbole1(struct hash_table *table, char *id, char *s) {
    unsigned int index = hash_function(id);
    struct data *courant = table->table[index];
    while (courant != NULL) {
        if ((strcmp(id, courant->id) == 0) && (strcmp(s, courant->fc_name) == 0)) {
            return courant;
        }
        courant = courant->next;
    }
    return NULL;
}

// Recherche l'ordre d'un symbole dans la table de hachage
int searchSymboleOrder(struct hash_table *table, char *id) {
    struct data * search = searchSymbole(table, id);
    if(search!=NULL){
        struct data * alname = searchSymbole(table, search->fc_name);
        if(alname != NULL){
            return 2 + 2*alname->nbpar + 2*alname->nbvar - 2*search->ordre;
        }
        else{
            return -1;
        }
    }
    return -1;
}

// Recherche l'ordre d'un symbole dans la table de hachage pour une fonction spécifique
int searchSymboleOrderFCT(struct hash_table *table, char *id, char * s) {
    struct data * search = searchSymbole1(table, id, s);
    if(search!=NULL){
        struct data * alname = searchSymbole1(table, search->fc_name, s);
        if(alname != NULL){
            return 2 + 2*alname->nbpar + 2*alname->nbvar - 2*search->ordre;
        }
        else{
            return -1;
        }
    }
    return -1;
}

// Libère la mémoire utilisée par la table de hachage et ses éléments
void freeTable(struct hash_table *table) {
    for (int i = 0; i < TABLE_SIZE; i++) {
        struct data *courant = table->table[i];
        while (courant != NULL) {
            struct data *temp = courant;
            courant = courant->next;
            free(temp->id);
            free(temp);
        }
    }
}

// Incrémente le nombre de paramètres pour un symbole donné
void incrementer_nbpar(struct hash_table *table, char *id) {
    struct data *symbole = searchSymbole(table, id);
    if (symbole != NULL) {
        (symbole->nbpar)++;
    } else {
        fprintf(stderr, "Symbole non trouvé : %s\n", id);
    }
}

// Convertit le type1 en chaîne de caractères pour l'affichage
const char *typeToString(type1 t) {
    switch (t) {
        case NUMBER:
            return "NUMBER";
        case BOOLEAN:
            return "BOOLEAN";
        case NONE:
            return "NONE";
        default:
            return "UNKNOWN";
    }
}

// Convertit le type2 en chaîne de caractères pour l'affichage
const char *typeVarToString(type2 t) {
    switch (t) {
        case FCT:
            return "FCT";
        case PARAM:
            return "PARAM";
        case VLOC:
            return "VLOC";
        case BLOC:
            return "BLOC";
        default:
            return "UNKNOWN";
    }
}

// Affiche la table de hachage des symboles
void afficherTableSymboles(struct hash_table *table) {
    printf(";Table des symboles :\n");
    printf(";---------------------\n");
    for (int i = 0; i < TABLE_SIZE; i++) {
        struct data *courant = table->table[i];
        while (courant != NULL) {
            // Affiche les informations sur chaque symbole
            printf(";ID : %s | Type : %s | Type variable : %s | Ordre : %d | Nbpar : %d | Nbvar : %d | FCT : %s\n",
                   courant->id, typeToString(courant->type), typeVarToString(courant->type_var),
                   courant->ordre, courant->nbpar, courant->nbvar, courant->fc_name);
            courant = courant->next;
        }
    }
}
